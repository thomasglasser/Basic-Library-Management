Steps to compile and run:
1. Open the terminal in the directory of the jar file
2. Run the command "java -jar BasicLibraryManagement-1.0.jar"

Overview: 
<br>
This basic library management system allows you to keep track of your books and patrons. 
You are able to add, update, and delete books and patrons. 
You can also search for books or see them all.
Use the numbers beside the choices as the input needed.